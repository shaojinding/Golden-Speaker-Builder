%STRAIGHT toolkit

addpath('./toolkits/STRAIGHT/');

%ARCTIC toolkit

addpath('./toolkits/ARCTIC/');

%RASTAMAT toolkit

addpath('./toolkits/rastamat/');

%PSI Utilities

addpath('./toolkits/PSI-utilities/');

%SPASMS-MATLAB

% addpath('./toolkits/spams-matlab/build/');

%SRV

addpath('./toolkits/srv1_9/');